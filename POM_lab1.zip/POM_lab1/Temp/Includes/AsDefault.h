#ifndef _DEFAULT_757602046
#define _DEFAULT_757602046
#include <bur/plctypes.h>
#include <bur/plc.h>

#ifdef __cplusplus 
extern "C" 
{
#endif
	#include <operator.h>
	#include <runtime.h>
	#include <McBase.h>
	#include <astime.h>
	#include <AsIecCon.h>
	#include <MotorCtrl.h>
#ifdef __cplusplus
};
#endif

#include <globalVAR.h>
#include <globalTYP.h>
#endif
